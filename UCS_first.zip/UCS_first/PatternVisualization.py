import numpy as np
import random
from mpl_toolkits.mplot3d import axes3d
import matplotlib.pyplot as plt
import os
import matplotlib.lines as mlines
import matplotlib as mpl
import copy
import os


class Value_Knowledge_Running:
    def __init__(self,path):
        self.png_path=path
        self.name=1
        print ("Start Value Knowledge Record")


    def General_Level(self,condition):
        count=0
        for cod in condition:
            if cod=='#':
                count+=1
        return count

    def Generate_Knowledge(self, population,length):
        #Initial the action based distribution list
        Rule_Number=[]
        for i in range(0,length+1):
            Rule_Number.append(0)


        distribution_list=[]
        #print len(self.negative_set)
        for i in range(0,length+1):
            temp=[]
            for j in range(0,length):               
                temp.append(0)
            distribution_list.append(temp)

        #Action distributed list

        
        G_distribution_list=copy.deepcopy(distribution_list)


        G_count_list=copy.deepcopy(G_distribution_list)


        for rule in population:
            g=self.General_Level(rule[0])
            Rule_Number[g]+=rule[2]
            for cond_l in range(0,length):
                
                if rule[0][cond_l]!='#':
                     G_distribution_list[g][cond_l]+=1
                     G_count_list[g][cond_l]+=1
                else:
                     G_count_list[g][cond_l]+=1

        for i in range(0, length+1):
            for d_l in range(0,length):
                        if G_count_list[i][d_l]!=0:
                            G_distribution_list[i][d_l]=1.0*G_distribution_list[i][d_l]/G_count_list[i][d_l]

        print (G_distribution_list)
        print(Rule_Number)
        return G_distribution_list,Rule_Number


    def Drew_NOACT(self,distribution_list,R_number,accuracy,iteration):
        fig=plt.figure(figsize=(10, 10), dpi=150)
        ax1=fig.add_subplot(111,projection='3d')
        z_first=np.asarray(distribution_list)
        z=z_first.T


        
        xlabels_t=[]       
        for i in range(0,len(z)):
            xlabels_t.append(str(i))
        xlabels=np.array(xlabels_t)
        xpos=np.arange(xlabels.shape[0])

        ylabels_t=[]       
        for i in range(0,len(z[0])):
            ylabels_t.append(str(i) +'('+ str(R_number[i])+')')
        ylabels=np.array(ylabels_t)
        ypos=np.arange(ylabels.shape[0])



        xposM, yposM=np.meshgrid(xpos,ypos,copy=False)

        dx=0.3
        dy=0.1

        ax1.w_xaxis.set_ticks(xpos + dx/2.)
        ax1.w_xaxis.set_ticklabels(xlabels)

        ax1.w_yaxis.set_ticks(ypos + dy/3.)
        ax1.w_yaxis.set_ticklabels(ylabels)

        color_list=['#EE7700','DarkGreen', 'Blue', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan','tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan']

        line_list=['--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':']
        #for act in range(6,7):
        
        z_first=np.asarray( distribution_list)
        z=z_first.T

        y=[]

        for i in range(0,len(z[0])):
            y.append(i)



        for i in range(0,len(z)):
            x=[i]*len(z[i])
            if len(z)>20:


                ax1.plot(x, y, z[i], line_list[act],color=color_list[act],lw=3,alpha=3)

                ax1.legend()
                for j in range(0,len(z[i])):
                    if z[i][j] !=0 and i%4==0:

                        ax1.text(i, j, z[i][j]+0.1, str(round(z[i][j],2)), color=color_list[0])  
            else:
                ax1.plot(x, y, z[i], line_list[0], color=color_list[0],lw=2)
                ax1.legend()
                for j in range(0,len(z[i])):
                    if z[i][j]!=0:
                        ax1.text(i, j, z[i][j]+0.01, str(round(z[i][j],2)), color=color_list[0])
 

            
                       


        ax1.set_xlabel('X ', fontsize=20)
        ax1.set_title('Accuracy: '+ str(accuracy) +"  Iterations: "+str(iteration), fontsize=20)
        ax1.set_ylabel('Y', fontsize=20)
        ax1.set_zlabel("Z", fontsize=20)


        for angle in range(115, 117,1):
           ax1.view_init(10, angle)
           plt.draw()
           png_complete_name = self.png_path + str(self.name) + ".png"
            # fig.savefig(png_complete_name, dpi=(400))
            #fig.savefig(png_complete_name,bbox_inches='tight')
           fig.savefig(png_complete_name)
           plt.pause(.001)
        self.name+=1
            #plt.pause(.001)